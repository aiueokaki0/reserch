/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Overrides of the Binary Max-Sum library's factors, to enable them to detect "infinite" values
 * and prune the corresponding variables.
 */
package RSLBench.Algorithms.TeamFormation.factor;
